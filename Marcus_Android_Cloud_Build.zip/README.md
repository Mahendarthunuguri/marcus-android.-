# Marcus Android cloud build (prototype)

This repository packages the current Marcus web prototype into an Android APK using Capacitor and GitHub Actions. The APK is a debug build for personal testing, not a Play Store release.

## Build from an Android phone

1. Sign in to GitHub in your mobile browser and create a **new public repository** named `marcus-android` (public repositories are eligible for free standard hosted runners under GitHub's current policy).
2. Upload the contents of this project to the repository, preserving the `.github/workflows/android.yml` path. If uploading a folder structure from Android is difficult, use GitHub's **Add file → Create new file** to create `.github/workflows/android.yml`, paste the workflow contents, then upload `package.json`, `capacitor.config.json`, and `www/index.html` with their paths preserved.
3. Open the repository's **Actions** tab, choose **Build Marcus Android APK**, and tap **Run workflow**. A push to `main` also starts a build.
4. When the run finishes green, open the run, scroll to **Artifacts**, and download `Marcus-debug-APK`. Extract the downloaded ZIP on your phone; inside is `app-debug.apk`.
5. Tap the APK to install. If Android asks, allow your browser or file manager to install unknown apps. Only install an APK you built from this source.

## What this build does and doesn't do

- Packages the current Marcus v0.2 interface as an Android app.
- Keeps local prototype functions such as notes, task list, calendar view, and office templates.
- Does **not** yet connect an online AI model, implement dependable native scheduled notifications, create accounts/login, or execute native phone actions. Those require additional development.
- The approval screen in this prototype is a demonstration; it does not control the phone.
- The current prototype calendar includes only a few fixed-date observances. Telugu lunar festival dates must be verified with an official yearly Panchangam.
- Do not put an AI provider secret/API key inside the APK or public repository. A secure online AI feature normally needs a server-side proxy. We should add that only after the first APK build is verified.

## App identity

- App name: Marcus
- Android package ID: `com.marcus.personalassistant`
- Build type: debug APK, suitable for testing
